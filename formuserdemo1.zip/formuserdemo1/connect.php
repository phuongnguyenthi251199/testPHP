<?php

$connect = mysqli_connect("localhost", "root", "");
$db = mysqli_select_db($connect, "formuserdemo1");
?>