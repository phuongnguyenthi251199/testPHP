<?php
require 'connect.php';
$id=(int)$_GET['id'];
$sql="DELETE FROM `userinfo` WHERE `id`={$id}";
if(!mysqli_query($connect, $sql)){
    die('Lỗi sql'.mysqli_error($connect));
}
header("Location: home.php");

?>

