<?php
require 'connect.php';
?>
<html>
    <head>
        <title>Đổi thông tin cá nhân</title>
        <meta charset="utf8">
        <meta name="viewport" content="width=device-width", initial-scale="1.0">
        <style>
            .box-content{
                margin: 0 auto;
                width: 800px;
                text-align: center;
                padding: 20px;
            }
            #edit_user form{
                width: 200px;
                margin: 40px auto;
            }
            #edit_user form input{
                margin: 5px 0;
            }
        </style>
    </head>
    <body>
        <div class="phan1">
            <div class="logo">
                <center><img src="https://media.istockphoto.com/vectors/welcom-header-colored-balloons-confetti-explosion-vector-id1160941940" width="400px" height="200px"/></center>
            </div>

        </div>
        <?php
        if (isset($_GET['action']) && $_GET['action'] == 'Sửa') {
            if (isset($_POST['id']) && !empty($_POST['id']) && isset($_POST['password']) && !empty($_POST['password'])) {
                $result = mysqli_query($connect, "UPDATE `userinfo` SET `password`=MD5('".$_POST['password']."'), `status` = ".$_POST['status']." WHERE `userinfo`.`id` = ".$_POST['id'].";");
                if (!$result) {
                    $error = "Không thể cập nhật tài khoản";
                }
                mysqli_close($connect);
                if ($error !== FALSE) {
                    ?>
                    <div id="error-notify" class="box-content">
                        <h1>Thông báo</h1>
                        <h4><?= $error ?></h4>
                        <a href="./home.php">Danh sách tài khoản</a>
                    </div>
                <?php } else { ?>
                <?php } ?>
                <div id="edit-notifi" class="box-content">
                    <h1><?= ($error !== FALSE) ? $error : "Sửa tài khoản thành công" ?></h1>
                    <a href="./home.php">Danh sách tài khoản </a>
                </div>
            <?php } else { ?>
        <div id="edit-notify" class="box-content">
            <h1>Vui lòng nhập đủ thông tin để sửa tài khoản</h1>
            <a href="./edit.php?id=<?=$_POST['id'] ?>">Quay lại sửa tài khoản </a>
        </div>
            <?php }
                } else {
                $result = mysqli_query($connect, "SELECT * FROM `userinfo` WHERE `id`=" . $_GET['id']);
                $user = $result->fetch_assoc();
                mysqli_close($connect);
                if (!empty($user)) {
                ?>
                <div id="edit_user" class="box-content">
                    <h2>Sửa tài khoản "<?= $user['username'] ?>"</h2>
                    <form action="./edit.php?action=Sửa" method="Post" autocomplete="off">
                        <label>Password</label>
                        <input type="hidden" name="id" value="<?= $user['id'] ?>">
                        <input type="password" name="password" value="">
                        <select name="status">
                            <option <?php if (!empty($user['status'])) { ?> selected <?php } ?>value="1" > Kích hoạt </option>
                            <option <?php if (!empty($user['status'])) { ?> selected <?php } ?>value="0" > Block </option>
                        </select>
                        <br><br>
                        <input type="submit" value="Sửa">
                    </form>
                </div>

                <?php
            }
        }
        ?>
    </body>
</html>


