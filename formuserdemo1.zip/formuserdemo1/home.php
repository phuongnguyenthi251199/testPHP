<?php
require 'connect.php';
$sql = "SELECT * FROM `userinfo`";
$result = mysqli_query($connect, $sql);
if (!$result) {
    die('Lỗi' . mysqli_errno($connect));
}
?>
<html>
    <head>
        <meta charset="utf8">
    </head>
    <style>
        .box-content{
            margin: 0 auto;
            width: 800px;
            text-align: center;
            padding: 20px;
        }
        .search-box{
            margin: 0 auto;
            width: 800p;
            text-align: center;
            padding: 20px;
        }
    </style>
    <body>
        <div class="phan1">
            <div class="logo">
                <center><img src="https://media.istockphoto.com/vectors/welcom-header-colored-balloons-confetti-explosion-vector-id1160941940" width="400px" height="200px"/></center>
            </div>
            <div class="search-box">
                <div class="container-1">
                    <span class="icon"><i class="fa fa-search"></i></span>
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjLMM898yY_qyM-9iVfcfgpr6J66spSSTBPlZXUJCJ0VaazkgU&s" width="15px" height="15px"> <input type="search" id="search" placeholder="Tìm kiếm..." />
                </div>
            </div>

        </div>
        <div class="box-content">
            <table border="1">
                <thead>
                    <tr>
                        <td>id</td>
                        <td>username</td>
                        <td>password</td>
                        <td>email</td>
                        <td>phone</td>
                        <td>gioitinh</td>
                        <td>Sửa</td>
                        <td>Xóa</td>
                        <td>Thông tin</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            ?>

                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['username']; ?></td>
                                <td><?php echo $row['password']; ?></td>
                                <td><?php echo $row['email']; ?></td>
                                <td><?php echo $row['phone']; ?></td>
                                <td><?php echo $row['gioitinh']; ?></td>
                                <td><a href="edit.php?id=<?php echo $row['id']; ?>">Sửa</a></td>
                                <td><a href="delete.php?id=<?php echo $row['id']; ?>">Xóa</a></td>
                                <td><a href="info.php?id=<?php echo $row['id']; ?>">Thông tin</a></td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>

            </table>
            <a href="http://localhost/formuserdemo1/index.php">Trở lại</a>
        </div>

    </body>
</html>