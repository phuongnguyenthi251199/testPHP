<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset=UTF-8" />
        <title>Demo Form User</title>
        <link type="text/css" href="css/style.css" rel="stylesheet"/>
        <script src="js/jquery.js"></script>
        <script>
            function dieu_huong_dn() {
                location.assign("http://localhost/formuserdemo1/login.php");
            }
            function dieu_huong_dk() {
                location.assign("http://localhost/formuserdemo1/signin.php");
            }
        </script>
        <style>
            body{
                background-image: url("nen1.jpg");
            }
        </style>
    </head>
    <body>
        <section class="full-box">
            <h1>Form User</h1>
            <article class="box-user">
                <h2>Welcom to my website !</h2>
                <img src="https://p.pngsee.com/uploadpng/small/218-2183218_computer-icons-login-youtube-yellow-circle-png-yellow.png"/>
                <div>
                    <button id="login" type="button" onclick="dieu_huong_dn()">Đăng nhập</button>
                    or <button id="signin" type="button" onclick="dieu_huong_dk()">Đăng kí</button>
                </div>
            </article>
        </section>
    </body>
</html>