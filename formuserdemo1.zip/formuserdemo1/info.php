<?php
require 'connect.php';
$id = (int) $_GET['id'];
$sql = "SELECT * FROM `userinfo` WHERE `id`={$id}";
$result = mysqli_query($connect, $sql);
if (!$result) {
    die('Lỗi' . mysqli_errno($connect));
}
$info_user = mysqli_fetch_assoc($result);
?>
<html>
    <head>
        <meta charset="utf8">
        <style>
            .box-content{
                margin: 0 auto;
                width: 800px;
                text-align: center;
                padding: 20px;
            }
            .box-content table{
                margin: 0 auto;
                width: 800px;
                text-align: center;
                padding: 20px;
            }
            .search-box{
                margin: 0 auto;
                width: 800px;
                text-align: center;
                padding: 20px;
            }
        </style>
    </head>
    <body>
        <div class="phan1">
            <div class="logo">
                <center><img src="https://media.istockphoto.com/vectors/welcom-header-colored-balloons-confetti-explosion-vector-id1160941940" width="400px" height="200px"/></center>
            </div>
            <div class="search-box">
                <div class="container-1">
                    <span class="icon"><i class="fa fa-search"></i></span>
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjLMM898yY_qyM-9iVfcfgpr6J66spSSTBPlZXUJCJ0VaazkgU&s" width="15px" height="15px"> <input type="search" id="search" placeholder="Tìm kiếm..." />
                </div>
            </div>
        </div>
        <div class="box-content">
            <h2 class="h22">Thông tin thành viên : <span style="color: red"><?php echo $info_user['username'] ?></span></h2>
            <table border="1">


                <tr>
                    <td>Tên</td>
                    <td><?php echo $info_user['username'] ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?php echo $info_user['email'] ?></td>
                </tr>
                <tr>
                    <td>Số điện thoại</td>
                    <td><?php echo $info_user['phone'] ?></td>
                </tr>
                <tr>
                    <td>Giới tính</td>
                    <td><?php echo $info_user['gioitinh'] ?></td>
                </tr>


            </table>
            <a href="http://localhost/formuserdemo1/home.php">Trở lại</a>
        </div>
    </body>
</html>