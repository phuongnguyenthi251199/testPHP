$(document).ready(function(){
                $('#login').click(function(){
                    location.href="login.php";
                });
                $('#signin').click(function(){
                    location.href="signin.php";
                });
            });
       
       
       
       
