<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset=UTF-8" />
        <title>Demo Form User| Đăng Nhập</title>
        <link type="text/css" href="css/style.css" rel="stylesheet"/>
        <script src="js/jquery.js"></script>
        <script>
            function dieu_huong_dn() {
                location.assign("http://localhost/formuserdemo1/login.php");
            }
            function dieu_huong_dk() {
                location.assign("http://localhost/formuserdemo1/signin.php");
            }
            function dieu_huong_quaylai() {
                location.assign("http://localhost/formuserdemo1/index.php");
            }
        </script>
        <style>
            body{
                background-image: url("nen1.jpg");
            }
        </style>
    </head>
    <body>
        <section class="full-box">
            <h1>Đăng nhập</h1>
            <article class="box-user">
                <form method="post">
                    <table>
                        <tr>
                            <td>Tên tài khoản</td>
                            <td><input name="username" placeholder="Tên tài khoản"/></td>
                        </tr>
                        <tr>
                            <td>Mật khẩu</td>
                            <td><input name="password" placeholder="Mật khẩu" type="password"/></td>
                        </tr>

                        <tr>
                            <td colspan="2" style="text-align:center"><input id="login" name="login-submit" value="Đăng nhập" type="submit" onclick="dieu_huong_dang_nhap_thanh_cong"/>     <input id="back" value="Quay lại" type="button" onclick="dieu_huong_quaylai()"/></td>
                        </tr>
                    </table>
                </form>
                <?php
                include 'connect.php';
                if (isset($_POST['login-submit'])) {
                    $username = $_POST['username'];
                    $password = $_POST['password'];
                    if ($username == "" || $password == "") {
                        echo '<p>Hãy điền đầy đủ thông tin của bạn !</p>';
                    } else {
                        $sql = "SELECT * FROM `userinfo` WHERE username='$username' and password='$password'";
                        $query = mysqli_query($connect, $sql);
                        $num_rows = mysqli_num_rows($query);
                        if ($num_rows != 0) {
                            echo '<p>Bạn đã đăng nhập thành công ! </p>';
                            header("Location: http://localhost/formuserdemo1/home.php");
                            die();
                        } else {
                            echo '<p>Bạn đăng nhập không thành công </p>';
                        }
                    }
                }
                ?>

            </article>
        </section>
    </body>
</html>