<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<head>
    <meta charset=UTF-8" />
    <title>Demo Form User | Đăng kí</title>
    <link type="text/css" href="css/style.css" rel="stylesheet"/>
    <script src="js/jquery.js"></script>
    <script>
        function dieu_huong_dn() {
            location.assign("http://localhost/formuserdemo1/login.php");
        }
        function dieu_huong_dk() {
            location.assign("http://localhost/formuserdemo1/signin.php");
        }
        function dieu_huong_quaylai() {
            location.assign("http://localhost/formuserdemo1/index.php");
        }
    </script>
    <style>
        body{
            background-image: url("nen1.jpg");
        }
    </style>
</head>
<body>
    <section class="full-box">
        <h1>Đăng kí</h1>
        <article class="box-user">
            <form method="post">
                <table>
                    <tr>
                        <td>Tên tài khoản</td>
                        <td><input name="username" placeholder="Tên tài khoản"/></td>
                    </tr>
                    <tr>
                        <td>Mật khẩu</td>
                        <td><input name="password" placeholder="Mật khẩu" type="password"/></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><input name="email" placeholder="Email"/></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td><input name="phone" placeholder="Số điện thoại"/></td>
                    </tr>
                    <tr>
                        <td>Giới tính</td>
                        <td><input name="gioitinh" value="Nam" type="radio"/>Nam <input name="gioitinh" value="Nữ" type="radio"/>Nữ</td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align:center"><input id="signin" name="sign-submit" value="Đăng kí" type="submit"/>     <input id="back" value="Quay lại" type="button" onclick="dieu_huong_quaylai()"/></td>
                    </tr>
                </table>
            </form>
            <?php
            include 'connect.php';
            if (isset($_POST['sign-submit'])) {
                $username = $_POST['username'];
                $password = $_POST['password'];
                $email = $_POST['email'];
                $phone = $_POST['phone'];
                $gioitinh = $_POST['gioitinh'];
                if ($username == "" || $password == "" || $email == "" || $phone == "" || $gioitinh == "") {
                    echo '<p>Hãy điền đầy đủ thông tin của bạn !</p>';
                } else {
                    $sql = "INSERT INTO `userinfo`(`username`, `password`, `email`, `phone`, `gioitinh`) VALUES('$username','$password','$email','$phone','$gioitinh')";
                    $query = mysqli_query($connect,$sql);
                    if($query!=0){
                        echo '<p>Hoàn thành !</p>';
                    }else{
                        echo '<p>Hoàn thành !</p>';
                    }
                }
            }
            ?>
        </article>
    </section>
</body>
</html>